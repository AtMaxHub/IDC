package com.anytron.mybatis.generator.plugins;


import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;

import java.util.List;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;

/**
 * 重命名mapper插件
 */
public class RenameMapperPlugin extends PluginAdapter {

    private String mapperSuffix;
    private String sqlSuffix;

    @Override
    public boolean validate(List<String> warnings) {
        //获取配置
        mapperSuffix = properties.getProperty("mapperSuffix");
        sqlSuffix = properties.getProperty("sqlSuffix");
        //至少一个配置
        return stringHasValue(mapperSuffix) || stringHasValue(sqlSuffix);
    }

    @Override
    public void initialized(IntrospectedTable introspectedTable) {
        String modelName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();
        if (stringHasValue(mapperSuffix)) {
            String mapperType = introspectedTable.getMyBatis3JavaMapperType();
            mapperType = mapperType.replaceAll(modelName + "Mapper", modelName + mapperSuffix);
            introspectedTable.setMyBatis3JavaMapperType(mapperType);
        }
        if (stringHasValue(sqlSuffix)) {
            introspectedTable.setMyBatis3XmlMapperFileName(modelName + sqlSuffix + ".xml");
        }
    }
}

