/*
 * Copyright (c) 2017.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.anytron.mybatis.generator.plugins.utils;

import java.util.Iterator;
import java.util.List;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.Field;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.InnerClass;
import org.mybatis.generator.api.dom.java.JavaVisibility;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.Parameter;
import org.mybatis.generator.api.dom.java.TopLevelClass;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Element;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
import org.mybatis.generator.config.GeneratedKey;

import com.anytron.mybatis.generator.plugins.utils.enhanced.GeneratorTools;

/**
 * ---------------------------------------------------------------------------
 * Xml 节点生成工具 参考 org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.AbstractXmlElementGenerator
 * ---------------------------------------------------------------------------
 *
 * @author: hewei
 * @time:2016/12/29 16:47
 * ---------------------------------------------------------------------------
 */
public class XmlElementGeneratorTools {

    /**
     * This method should return an XmlElement for the select key used to
     * automatically generate keys.
     *
     * @param introspectedColumn the column related to the select key statement
     * @param generatedKey       the generated key for the current table
     * @return the selectKey element
     */
    public static XmlElement getSelectKey(IntrospectedColumn introspectedColumn, GeneratedKey generatedKey) {
        String identityColumnType = introspectedColumn.getFullyQualifiedJavaType().getFullyQualifiedName();

        XmlElement answer = new XmlElement("selectKey");
        answer.addAttribute(new Attribute("resultType", identityColumnType));
        answer.addAttribute(new Attribute("keyProperty", introspectedColumn.getJavaProperty()));
        answer.addAttribute(new Attribute("order", generatedKey.getMyBatis3Order()));

        answer.addElement(new TextElement(generatedKey.getRuntimeSqlStatement()));

        return answer;
    }

    /**
     * 获取数据库自增主键 自动生成 selectKey
     *
     * @param element
     * @param introspectedTable
     */
    public static void addSelectKeyByData(XmlElement element, IntrospectedTable introspectedTable) {
        IntrospectedColumn keyColumn = GeneratorTools.getKeyColumn(introspectedTable);
        GeneratedKey generatedKey = new GeneratedKey(keyColumn.getActualColumnName(), "Mysql", true, "post");
        if (keyColumn != null) {
            element.addElement(getSelectKey(keyColumn, generatedKey));
        }
    }

    /**
     * 获取配置文件中的GeneratedKey 自动生成 selectKey
     *
     * @param element
     * @param introspectedTable
     */
    public static void addSelectKeyByConfig(XmlElement element, IntrospectedTable introspectedTable) {
        GeneratedKey generatedKey = introspectedTable.getGeneratedKey();
        IntrospectedColumn keyColumn = introspectedTable.getColumn(generatedKey.getColumn());
        if (keyColumn != null) {
            element.addElement(getSelectKey(keyColumn, generatedKey));
        }
    }

    /**
     * 获取数据库自增主键 自动生成useGeneratedKeys
     *
     * @param element
     * @param introspectedTable
     */
    public static void useGeneratedKeysByData(XmlElement element, IntrospectedTable introspectedTable) {
        IntrospectedColumn keyColumn = GeneratorTools.getKeyColumn(introspectedTable);
        if (keyColumn != null) {
            useGeneratedKeys(element, keyColumn);
        }
    }

    /**
     * 获取配置文件中的GeneratedKey 生成useGeneratedKeys
     *
     * @param element
     * @param introspectedTable
     */
    public static void useGeneratedKeysByConfig(XmlElement element, IntrospectedTable introspectedTable) {
        GeneratedKey gk = introspectedTable.getGeneratedKey();
        if (gk != null) {
            IntrospectedColumn keyColumn = introspectedTable.getColumn(gk.getColumn());
            if (keyColumn != null) {
                useGeneratedKeys(element, keyColumn);
            }
        }
    }

    /**
     * 生成useGeneratedKeys
     *
     * @param element
     * @param keyColumn
     */
    public static void useGeneratedKeys(XmlElement element, IntrospectedColumn keyColumn) {
        //使用JDBC的getGenereatedKeys方法获取主键并赋值到keyProperty设置的领域模型属性中。所以只支持MYSQL和SQLServer
        //因为我们要添加的属性就是insert元素上的，而insert元素就是根节点，所以element就是insert元素；
        element.addAttribute(new Attribute("useGeneratedKeys", "true"));
        //通过IntrospectedColumn的getActualColumnName得到列中的名称，用于生成keyColumn属性；
        element.addAttribute(new Attribute("keyColumn", keyColumn.getActualColumnName()));
        //通过IntrospectedColumn的getJavaProperty方法得到key在Java对象中的属性名，用于生成keyProperty属性
        element.addAttribute(new Attribute("keyProperty", keyColumn.getJavaProperty()));
    }

    /**
     * 使用JDBC的getGenereatedKeys方法获取主键并赋值到keyProperty设置的领域模型属性中。所以只支持MYSQL和SQLServer
     *
     * @param element
     * @param introspectedTable
     */
    public static void useGeneratedKeys(XmlElement element, IntrospectedTable introspectedTable) {
        useGeneratedKeys(element, introspectedTable, null);
    }

    /**
     * 使用JDBC的getGenereatedKeys方法获取主键并赋值到keyProperty设置的领域模型属性中。所以只支持MYSQL和SQLServer
     *
     * @param element
     * @param introspectedTable
     * @param prefix
     */
    public static void useGeneratedKeys(XmlElement element, IntrospectedTable introspectedTable, String prefix) {
        GeneratedKey gk = introspectedTable.getGeneratedKey();
        if (gk != null) {
            IntrospectedColumn introspectedColumn = introspectedTable.getColumn(gk.getColumn());
            // if the column is null, then it's a configuration error. The
            // warning has already been reported
            if (introspectedColumn != null) {
                // 使用JDBC的getGenereatedKeys方法获取主键并赋值到keyProperty设置的领域模型属性中。所以只支持MYSQL和SQLServer
                element.addAttribute(new Attribute("useGeneratedKeys", "true"));
                element.addAttribute(new Attribute("keyProperty", (prefix == null ? "" : prefix) + introspectedColumn.getJavaProperty()));
                element.addAttribute(new Attribute("keyColumn", introspectedColumn.getActualColumnName()));
            }
        }
    }

    public static XmlElement getBaseColumnListElement(IntrospectedTable introspectedTable) {
        XmlElement answer = new XmlElement("include");
        answer.addAttribute(new Attribute("refid",
                introspectedTable.getBaseColumnListId()));
        return answer;
    }

    public static XmlElement getBlobColumnListElement(IntrospectedTable introspectedTable) {
        XmlElement answer = new XmlElement("include");
        answer.addAttribute(new Attribute("refid",
                introspectedTable.getBlobColumnListId()));
        return answer;
    }

    public static XmlElement getExampleIncludeElement(IntrospectedTable introspectedTable) {
        XmlElement ifElement = new XmlElement("if");
        ifElement.addAttribute(new Attribute("test", "_parameter != null"));

        XmlElement includeElement = new XmlElement("include");
        includeElement.addAttribute(new Attribute("refid",
                introspectedTable.getExampleWhereClauseId()));
        ifElement.addElement(includeElement);

        return ifElement;
    }

    public static XmlElement getUpdateByExampleIncludeElement(IntrospectedTable introspectedTable) {
        XmlElement ifElement = new XmlElement("if");
        ifElement.addAttribute(new Attribute("test", "_parameter != null"));

        XmlElement includeElement = new XmlElement("include");
        includeElement.addAttribute(new Attribute("refid",
                introspectedTable.getMyBatis3UpdateByExampleWhereClauseId()));
        ifElement.addElement(includeElement);

        return ifElement;
    }

    /**
     * 生成keys Ele
     *
     * @param columns
     * @return
     */
    public static TextElement generateKeys(List<IntrospectedColumn> columns) {
        return generateKeys(columns, true);
    }

    /**
     * 生成keys Ele
     *
     * @param columns
     * @param bracket
     * @return
     */
    public static TextElement generateKeys(List<IntrospectedColumn> columns, boolean bracket) {
        return generateCommColumns(columns, null, bracket, 1);
    }

    /**
     * 生成keys Selective Ele
     *
     * @param columns
     * @return
     */
    public static XmlElement generateKeysSelective(List<IntrospectedColumn> columns) {
        return generateKeysSelective(columns, null);
    }

    /**
     * 生成keys Selective Ele
     *
     * @param columns
     * @param prefix
     * @return
     */
    public static XmlElement generateKeysSelective(List<IntrospectedColumn> columns, String prefix) {
        return generateKeysSelective(columns, prefix, true);
    }

    /**
     * 生成keys Selective Ele
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @return
     */
    public static XmlElement generateKeysSelective(List<IntrospectedColumn> columns, String prefix, boolean bracket) {
        return generateCommColumnsSelective(columns, prefix, bracket, 1);
    }

    /**
     * 生成values Ele
     *
     * @param columns
     * @return
     */
    public static TextElement generateValues(List<IntrospectedColumn> columns) {
        return generateValues(columns, null);
    }

    /**
     * 生成values Ele
     *
     * @param columns
     * @param prefix
     * @return
     */
    public static TextElement generateValues(List<IntrospectedColumn> columns, String prefix) {
        return generateValues(columns, prefix, true);
    }

    /**
     * 生成values Ele
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @return
     */
    public static TextElement generateValues(List<IntrospectedColumn> columns, String prefix, boolean bracket) {
        return generateCommColumns(columns, prefix, bracket, 2);
    }

    /**
     * 生成values Selective Ele
     *
     * @param columns
     * @return
     */
    public static XmlElement generateValuesSelective(List<IntrospectedColumn> columns) {
        return generateValuesSelective(columns, null);
    }

    /**
     * 生成values Selective Ele
     *
     * @param columns
     * @param prefix
     * @return
     */
    public static XmlElement generateValuesSelective(List<IntrospectedColumn> columns, String prefix) {
        return generateValuesSelective(columns, prefix, true);
    }

    /**
     * 生成values Selective Ele
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @return
     */
    public static XmlElement generateValuesSelective(List<IntrospectedColumn> columns, String prefix, boolean bracket) {
        return generateCommColumnsSelective(columns, prefix, bracket, 2);
    }

    /**
     * 生成sets Ele
     *
     * @param columns
     * @return
     */
    public static TextElement generateSets(List<IntrospectedColumn> columns) {
        return generateSets(columns, null, false);
    }

    /**
     * 生成sets Ele
     *
     * @param columns
     * @param prefix
     * @return
     */
    public static TextElement generateSets(List<IntrospectedColumn> columns, String prefix) {
        return generateSets(columns, prefix, false);
    }

    /**
     * 生成sets Ele
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @return
     */
    public static TextElement generateSets(List<IntrospectedColumn> columns, String prefix, boolean bracket) {
        return generateCommColumns(columns, prefix, bracket, 3);
    }

    /**
     * 生成sets Selective Ele
     *
     * @param columns
     * @return
     */
    public static XmlElement generateSetsSelective(List<IntrospectedColumn> columns) {
        return generateSetsSelective(columns, null, false);
    }

    /**
     * 生成sets Selective Ele
     *
     * @param columns
     * @param prefix
     * @return
     */
    public static XmlElement generateSetsSelective(List<IntrospectedColumn> columns, String prefix) {
        return generateSetsSelective(columns, prefix, false);
    }

    /**
     * 生成sets Selective Ele
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @return
     */
    public static XmlElement generateSetsSelective(List<IntrospectedColumn> columns, String prefix, boolean bracket) {
        return generateCommColumnsSelective(columns, prefix, bracket, 3);
    }

    /**
     * 通用遍历columns
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @param type    1:key,2:value,3:set
     * @return
     */
    private static TextElement generateCommColumns(List<IntrospectedColumn> columns, String prefix, boolean bracket, int type) {
        StringBuffer sb = new StringBuffer(bracket ? "(" : "");
        Iterator<IntrospectedColumn> columnIterator = columns.iterator();
        while (columnIterator.hasNext()) {
            IntrospectedColumn introspectedColumn = columnIterator.next();

            switch (type) {
                case 3:
                    sb.append(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
                    sb.append(" = ");
                    sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, prefix));
                    break;
                case 2:
                    sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, prefix));
                    break;
                case 1:
                    sb.append(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
                    break;
            }

            if (columnIterator.hasNext()) {
                sb.append(", ");
            }
        }

        return new TextElement(sb.append(bracket ? ")" : "").toString());
    }

    /**
     * 通用遍历columns
     *
     * @param columns
     * @param prefix
     * @param bracket
     * @param type    1:key,2:value,3:set
     * @return
     */
    private static XmlElement generateCommColumnsSelective(List<IntrospectedColumn> columns, String prefix, boolean bracket, int type) {
        XmlElement eleTrim = new XmlElement("trim");
        if (bracket) {
            eleTrim.addAttribute(new Attribute("prefix", "("));
            eleTrim.addAttribute(new Attribute("suffix", ")"));
            eleTrim.addAttribute(new Attribute("suffixOverrides", ","));
        } else {
            eleTrim.addAttribute(new Attribute("suffixOverrides", ","));
        }

        for (IntrospectedColumn introspectedColumn : columns) {
            XmlElement eleIf = new XmlElement("if");
            eleIf.addAttribute(new Attribute("test", introspectedColumn.getJavaProperty(prefix) + " != null"));

            switch (type) {
                case 3:
                    eleIf.addElement(new TextElement(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn) + " = " + MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, prefix) + ","));
                    break;
                case 2:
                    eleIf.addElement(new TextElement(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, prefix) + ","));
                    break;
                case 1:
                    eleIf.addElement(new TextElement(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn) + ","));
                    break;
            }

            eleTrim.addElement(eleIf);
        }

        return eleTrim;
    }

    public static void generateTextBlock(String text, XmlElement parent) {
        parent.addElement(new TextElement(text));
    }

    public static void generateTextBlockAppendTableName(String text, IntrospectedTable introspectedTable, XmlElement parent) {
        StringBuilder sb = new StringBuilder();
        sb.append(text);
        sb.append(introspectedTable.getAliasedFullyQualifiedTableNameAtRuntime());
        parent.addElement(new TextElement(sb.toString()));
    }

    public static void generateParameterForSet(List<IntrospectedColumn> columns, XmlElement parent) {
        generateParameterForSet("", false, columns, parent);
    }

    public static void generateParameterForSet(String fieldPrefix, List<IntrospectedColumn> columns, XmlElement parent) {
        generateParameterForSet(fieldPrefix, false, columns, parent);
    }

    public static void generateParameterForSet(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement dynamicElement) {
        XmlElement trimElement = new XmlElement("trim");
        trimElement.addAttribute(new Attribute("suffixOverrides", ","));

        StringBuilder sb = new StringBuilder();
        for (IntrospectedColumn introspectedColumn : columns) {
            sb.setLength(0);
            sb.append(MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
            sb.append(" = ");
            sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, fieldPrefix));
            sb.append(',');

            doIfNullCheck(fieldPrefix, ifNullCheck, trimElement, sb, introspectedColumn);
        }

        dynamicElement.addElement(trimElement);
    }

    public static void doIfNullCheck(String fieldPrefix, boolean ifNullCheck, XmlElement trimElement, StringBuilder sb, IntrospectedColumn introspectedColumn) {
        Element content;
        if (ifNullCheck) {
            content = wrapIfNullCheckForJavaProperty(fieldPrefix, new TextElement(sb.toString()), introspectedColumn);
        } else {
            content = new TextElement(sb.toString());
        }
        trimElement.addElement(content);
    }

    public static XmlElement wrapIfNullCheckForJavaProperty(String fieldPrefix, Element content, IntrospectedColumn introspectedColumn) {
        StringBuilder sb = new StringBuilder();
        XmlElement isNotNullElement = new XmlElement("if");
        sb.setLength(0);
        sb.append(introspectedColumn.getJavaProperty(fieldPrefix));
        sb.append(" != null");
        isNotNullElement.addAttribute(new Attribute("test", sb.toString()));
        isNotNullElement.addElement(content);
        return isNotNullElement;
    }

    public static void generateParametersSeparateByComma(List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByComma("", false, columns, parent);
    }

    public static void generateParametersSeparateByComma(String fieldPrefix, List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByComma(fieldPrefix, false, columns, parent);
    }

    public static void generateParametersSeparateByComma(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByComma(fieldPrefix, ifNullCheck, false, columns, parent);
    }

    public static void generateParametersSeparateByComma(String fieldPrefix, boolean ifNullCheck, boolean withParenthesis, List<IntrospectedColumn> columns, XmlElement parent) {
        XmlElement trimElement = new XmlElement("trim");
        trimElement.addAttribute(new Attribute("suffixOverrides", ","));
        if (withParenthesis) {
            trimElement.addAttribute(new Attribute("prefix", "("));
            trimElement.addAttribute(new Attribute("suffix", ")"));
        }

        StringBuilder sb = new StringBuilder();
        for (IntrospectedColumn introspectedColumn : columns) {
            sb.setLength(0);
            sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, fieldPrefix));
            sb.append(",");

            doIfNullCheck(fieldPrefix, ifNullCheck, trimElement, sb, introspectedColumn);
        }
        parent.addElement(trimElement);
    }

    public static void generateParametersSeparateByCommaWithParenthesis(List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByCommaWithParenthesis("", false, columns, parent);
    }

    public static void generateParametersSeparateByCommaWithParenthesis(String fieldPrefix, List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByCommaWithParenthesis(fieldPrefix, false, columns, parent);
    }

    public static void generateParametersSeparateByCommaWithParenthesis(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        generateParametersSeparateByComma(fieldPrefix, ifNullCheck, true, columns, parent);
    }

    public static void generateActualColumnNamesWithParenthesis(List<IntrospectedColumn> columns, XmlElement parent) {
        generateActualColumnNamesWithParenthesis("", false, columns, parent);
    }

    public static void generateActualColumnNamesWithParenthesis(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        generateActualColumnNamesWithParenthesis(fieldPrefix, null, ifNullCheck, columns, parent);
    }

    public static void generateActualColumnNamesWithParenthesis(String fieldPrefix, String columnPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        XmlElement trimElement = new XmlElement("trim");
        trimElement.addAttribute(new Attribute("suffixOverrides", ","));
        trimElement.addAttribute(new Attribute("prefix", "("));
        trimElement.addAttribute(new Attribute("suffix", ")"));

        StringBuilder sb = new StringBuilder();
        for (IntrospectedColumn introspectedColumn : columns) {
            sb.setLength(0);
            sb.append((columnPrefix == null ? "" : columnPrefix) + MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
            sb.append(",");

            doIfNullCheck(fieldPrefix, ifNullCheck, trimElement, sb, introspectedColumn);
        }

        parent.addElement(trimElement);
    }

    public static void generateWhereConditions(String fieldPrefix, List<IntrospectedColumn> columns, XmlElement parent) {
        generateWhereConditions(fieldPrefix, false, columns, parent);
    }

    public static void generateWhereConditions(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        generateWhereConditions(fieldPrefix, null, ifNullCheck, columns, parent);
    }

    public static void generateWhereConditions(String fieldPrefix, String columnPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement parent) {
        XmlElement trimElement = new XmlElement("trim");
        trimElement.addAttribute(new Attribute("suffixOverrides", ","));

        StringBuilder sb = new StringBuilder();
        for (IntrospectedColumn introspectedColumn : columns) {
            sb.setLength(0);
            sb.append((columnPrefix == null ? "" : columnPrefix) + MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
            sb.append(" = ");
            sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, fieldPrefix));
            sb.append(",");

            doIfNullCheck(fieldPrefix, ifNullCheck, trimElement, sb, introspectedColumn);
        }

        XmlElement where = new XmlElement("where");
        where.addElement(trimElement);
        parent.addElement(where);
    }

  /*---------------
   * Generate Helper Method For Java Source
   **--------------*/

    public static void generateGetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        Method method = new Method();
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get" + capitalize(field));
        method.setReturnType(type);
        method.addBodyLine("return this." + field + ";");
        innerClass.addMethod(method);
    }

    public static void generateSetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        Method method = new Method();
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("set" + capitalize(field));
        method.addParameter(new Parameter(type, field));
        method.addBodyLine("this." + field + " = " + field + ";");
        innerClass.addMethod(method);
    }

    public static void generateGetterSetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        generateSetterFor(field, type, innerClass);
        generateGetterFor(field, type, innerClass);
    }

    public static Field generateFieldDeclarationFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        Field ff = new Field();
        ff.setVisibility(JavaVisibility.PROTECTED);
        ff.setType(type);
        ff.setName(field);
        innerClass.addField(ff);
        return ff;
    }

    public static Field generateFieldDeclarationWithGetterSetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        generateGetterSetterFor(field, type, innerClass);
        return generateFieldDeclarationFor(field, type, innerClass);
    }

    public static Field generateFieldDeclarationWithFluentApiFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        generateFluentGetterFor(field, type, innerClass);
        generateFluentSetterFor(field, type, innerClass);
        return generateFieldDeclarationFor(field, type, innerClass);
    }

    public static void generateFluentSetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        Method method = new Method();
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName(field);
        method.addParameter(new Parameter(type, field));
        method.addBodyLine("this." + field + " = " + field + ";");
        method.addBodyLine("return this;");
        method.setReturnType(innerClass.getType());
        innerClass.addMethod(method);
    }

    public static void generateFluentGetterFor(String field, FullyQualifiedJavaType type, InnerClass innerClass) {
        Method method = new Method();
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName(field);
        method.addBodyLine("return this." + field + ";");
        method.setReturnType(type);
        innerClass.addMethod(method);
    }

    public static void generateBuilderFor(TopLevelClass topLevelClass) {
        if (topLevelClass == null || topLevelClass.getFields() == null || topLevelClass.getFields().isEmpty()) return;
        generateBuilderFor(topLevelClass.getType().getShortName(), topLevelClass, topLevelClass.getFields());
    }

    public static void generateBuilderFor(String builderName, TopLevelClass topLevelClass, List<Field> fields) {
        if (fields == null || fields.isEmpty()) return;

        FullyQualifiedJavaType builderType = new FullyQualifiedJavaType(builderName);

        InnerClass builder = new InnerClass(builderType);
        builder.setVisibility(JavaVisibility.PUBLIC);
        builder.setStatic(false);

        // build method and builder field
        Method method = new Method();
        method.setName("build");
        method.setVisibility(JavaVisibility.PUBLIC);

        for (Field field : fields) {
            generateFieldDeclarationWithFluentApiFor(field.getName(), field.getType(), builder);
            method.addBodyLine(topLevelClass.getType().getShortName() + ".this." + field.getName() + " = " + field.getName() + ";");
        }

        method.addBodyLine("return " + topLevelClass.getType().getShortName() + ".this;");
        method.setReturnType(topLevelClass.getType());
        builder.addMethod(method);

        // builder owner's builder()
        method = new Method();
        method.setName(uncapitalize(builderName));
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addBodyLine("return new " + builderName + "();");
        method.setReturnType(builderType);
        topLevelClass.addMethod(method);

        topLevelClass.addInnerClass(builder);
    }


    public static String capitalize(final String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return str;
        }

        char firstChar = str.charAt(0);
        if (Character.isTitleCase(firstChar)) {
            // already capitalized
            return str;
        }

        return new StringBuilder(strLen)
                .append(Character.toTitleCase(firstChar))
                .append(str.substring(1))
                .toString();
    }

    public static String uncapitalize(final String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return str;
        }

        char firstChar = str.charAt(0);
        if (Character.isLowerCase(firstChar)) {
            // already uncapitalized
            return str;
        }

        return new StringBuilder(strLen)
                .append(Character.toLowerCase(firstChar))
                .append(str.substring(1))
                .toString();
    }


}
