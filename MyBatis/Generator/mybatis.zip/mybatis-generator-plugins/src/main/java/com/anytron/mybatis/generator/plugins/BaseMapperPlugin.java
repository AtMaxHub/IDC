package com.anytron.mybatis.generator.plugins;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;

import java.util.List;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.TopLevelClass;

/**
 * 类名: BaseMapperPlugin
 * <br/>包名 com.anytron.mybatis.generator.plugins
 * <br/>作用: 生成的mapper继承BaseMapper
 * <br/>作者: YanPengJie
 * <br/>日期: 2018年5月24日下午8:21:21
 * <br/>版本: @version V1.0
 */
public class BaseMapperPlugin extends PluginAdapter {

	private String baseMapper;
	
	public boolean validate(List<String> warnings) {
		//获取配置
		baseMapper = properties.getProperty("baseMapper");
        return stringHasValue(baseMapper);
	}

	public String getBaseMapper() {
		return baseMapper;
	}

	public void setBaseMapper(String baseMapper) {
		this.baseMapper = baseMapper;
	}

	@Override
	public boolean clientGenerated(Interface interfaze,
			TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
		String[] split = baseMapper.split("\\.");
		FullyQualifiedJavaType superInterface = new FullyQualifiedJavaType(split[split.length-1]+"<"+ introspectedTable.getBaseRecordType() +","+introspectedTable.getExampleType()+">");
		FullyQualifiedJavaType importedType = new FullyQualifiedJavaType(baseMapper);
		//方法不需要
		interfaze.getMethods().clear();
		interfaze.getAnnotations().clear();
		//添加 extends BaseMapper
		interfaze.addSuperInterface(superInterface);
		//添加 import BaseMapper
		interfaze.addImportedType(importedType);
		return true;
	}

}