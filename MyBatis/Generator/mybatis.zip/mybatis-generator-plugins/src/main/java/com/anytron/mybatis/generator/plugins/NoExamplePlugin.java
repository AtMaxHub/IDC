package com.anytron.mybatis.generator.plugins;

import java.util.List;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;

/**
 * Mysql 去除example
 * Created by zhaojinpeng on 2017/6/21.
 */
public class NoExamplePlugin extends PluginAdapter {

    @Override
    public boolean validate(List<String> list) {
        return true;
    }

    @Override
    public void initialized(IntrospectedTable introspectedTable) {

        introspectedTable.getTableConfiguration().setSelectByExampleStatementEnabled(false);
        introspectedTable.getTableConfiguration().setUpdateByExampleStatementEnabled(false);
        introspectedTable.getTableConfiguration().setDeleteByExampleStatementEnabled(false);
        introspectedTable.getTableConfiguration().setCountByExampleStatementEnabled(false);
        super.initialized(introspectedTable);

    }

}
