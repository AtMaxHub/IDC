package com.anytron.mybatis.generator.plugins;

import java.util.List;
import java.util.Set;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.JavaVisibility;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.Parameter;
import org.mybatis.generator.api.dom.java.TopLevelClass;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.api.dom.xml.Element;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;

import com.anytron.mybatis.generator.plugins.utils.BasePlugin;
import com.anytron.mybatis.generator.plugins.utils.JavaElementGeneratorTools;
import com.anytron.mybatis.generator.plugins.utils.XmlElementGeneratorTools;

/**
 * 类名: SelectPlugin
 * <br/>包名 com.anytron.mybatis.generator.plugins
 * <br/>作用: 基础查询插件
 * <br/>作者: YanPengJie
 * <br/>日期: 2018年5月25日上午11:41:57
 * <br/>版本: @version V1.0
 */
public class SelectPlugin extends BasePlugin {

    public static final String SELECT_ALL = "selectAll";
    public static final String SELECT_ONE = "selectOne";
    public static final String SELECT = "select";

    @Override
    public boolean validate(List<String> warnings) {
        return true;
    }

	@Override
    public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
		
		FullyQualifiedJavaType listType = FullyQualifiedJavaType.getNewListInstance();
        Set<FullyQualifiedJavaType> importedTypes = interfaze.getImportedTypes();
        if (!importedTypes.contains(listType)){
            interfaze.addImportedType(listType);
        }
        listType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        
		Method selectAll = JavaElementGeneratorTools.generateMethod(
				SELECT_ALL,
                JavaVisibility.DEFAULT,
                listType
        );
        commentGenerator.addGeneralMethodComment(selectAll, introspectedTable);
        // interface 增加方法
        interfaze.addMethod(selectAll);
        
        Method selectOne = JavaElementGeneratorTools.generateMethod(
        		SELECT_ONE,
        		JavaVisibility.DEFAULT,
        		introspectedTable.getRules().calculateAllFieldsClass(),
        		new Parameter(JavaElementGeneratorTools.getModelTypeWithoutBLOBs(introspectedTable), "record")
        		);
        commentGenerator.addGeneralMethodComment(selectOne, introspectedTable);
        // interface 增加方法
        interfaze.addMethod(selectOne);
        
        Method select = JavaElementGeneratorTools.generateMethod(
        		SELECT,
        		JavaVisibility.DEFAULT,
        		listType,
        		new Parameter(JavaElementGeneratorTools.getModelTypeWithoutBLOBs(introspectedTable), "record")
        		);
        commentGenerator.addGeneralMethodComment(select, introspectedTable);
        // interface 增加方法
        interfaze.addMethod(select);
        return true;
    }


    @Override
    public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable) {
    	String resultMapId;
    	if (introspectedTable.hasBLOBColumns()) {
    		resultMapId = introspectedTable.getResultMapWithBLOBsId();
    	}else{
    		resultMapId = introspectedTable.getBaseResultMapId();
    	}
    	StringBuilder sb = new StringBuilder();
        XmlElement select_all = new XmlElement("select");
        select_all.addAttribute(new Attribute("id", SELECT_ALL));
        select_all.addAttribute(new Attribute("resultMap",resultMapId));
        select_all.addElement(new TextElement("select"));
        
        select_all.addElement(XmlElementGeneratorTools.getBaseColumnListElement(introspectedTable));
        if (introspectedTable.hasBLOBColumns()) {
        	select_all.addElement(new TextElement(","));
        	select_all.addElement(XmlElementGeneratorTools.getBlobColumnListElement(introspectedTable));
        }
        sb.setLength(0);
        sb.append("from ");
        sb.append(introspectedTable.getAliasedFullyQualifiedTableNameAtRuntime());
        select_all.addElement(new TextElement(sb.toString()));
        document.getRootElement().addElement(select_all);
        
        XmlElement select_one = new XmlElement("select");
        select_one.addAttribute(new Attribute("id", SELECT_ONE));
        // 添加返回类型
        select_one.addAttribute(new Attribute("resultMap", resultMapId));
        // 添加参数类型
        select_one.addAttribute(new Attribute("parameterType", JavaElementGeneratorTools.getModelTypeWithoutBLOBs(introspectedTable).getFullyQualifiedName()));
        select_one.addElement(new TextElement("select"));
        select_one.addElement(XmlElementGeneratorTools.getBaseColumnListElement(introspectedTable));
        if (introspectedTable.hasBLOBColumns()) {
        	select_one.addElement(new TextElement(","));
        	select_one.addElement(XmlElementGeneratorTools.getBlobColumnListElement(introspectedTable));
        }
        sb.setLength(0);
        sb.append("from ");
        sb.append(introspectedTable.getAliasedFullyQualifiedTableNameAtRuntime());
        select_one.addElement(new TextElement(sb.toString()));
        generateParameterForWhere(null,true, introspectedTable.getAllColumns(), select_one);
        select_one.addElement(new TextElement(" limit 1"));
        document.getRootElement().addElement(select_one);
        
        XmlElement select = new XmlElement("select");
        select.addAttribute(new Attribute("id", SELECT));
        // 添加返回类型
        select.addAttribute(new Attribute("resultMap", resultMapId ));
        // 添加参数类型
        select.addAttribute(new Attribute("parameterType", JavaElementGeneratorTools.getModelTypeWithoutBLOBs(introspectedTable).getFullyQualifiedName()));
        select.addElement(new TextElement("select"));
        select.addElement(XmlElementGeneratorTools.getBaseColumnListElement(introspectedTable));
        if (introspectedTable.hasBLOBColumns()) {
        	select.addElement(new TextElement(","));
        	select.addElement(XmlElementGeneratorTools.getBlobColumnListElement(introspectedTable));
        }
        sb.setLength(0);
        sb.append("from ");
        sb.append(introspectedTable.getAliasedFullyQualifiedTableNameAtRuntime());
        select.addElement(new TextElement(sb.toString()));
        generateParameterForWhere(null,true, introspectedTable.getAllColumns(), select);
        document.getRootElement().addElement(select);

        return true;
    }

    
    public static void generateParameterForWhere(String fieldPrefix, boolean ifNullCheck, List<IntrospectedColumn> columns, XmlElement dynamicElement) {
    	XmlElement whereElement = new XmlElement("where");
        StringBuilder sb = new StringBuilder();
        for (IntrospectedColumn introspectedColumn : columns) {
            sb.setLength(0);
            sb.append("and ");
            sb.append(MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
            sb.append(" = ");
            sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, fieldPrefix));
            doIfNullCheck(fieldPrefix, ifNullCheck, whereElement, sb, introspectedColumn);
        }
        dynamicElement.addElement(whereElement);
    }

    public static void doIfNullCheck(String fieldPrefix, boolean ifNullCheck, XmlElement trimElement, StringBuilder sb, IntrospectedColumn introspectedColumn) {
        Element content;
        if (ifNullCheck) {
            content = wrapIfNullCheckForJavaProperty(fieldPrefix, new TextElement(sb.toString()), introspectedColumn);
        } else {
            content = new TextElement(sb.toString());
        }
        trimElement.addElement(content);
    }

    public static XmlElement wrapIfNullCheckForJavaProperty(String fieldPrefix, Element content, IntrospectedColumn introspectedColumn) {
        StringBuilder sb = new StringBuilder();
        XmlElement isNotNullElement = new XmlElement("if");
        sb.setLength(0);
        sb.append(introspectedColumn.getJavaProperty(fieldPrefix));
        sb.append(" != null and ");
        sb.append(introspectedColumn.getJavaProperty(fieldPrefix));
        sb.append(" != ''");
        isNotNullElement.addAttribute(new Attribute("test", sb.toString()));
        isNotNullElement.addElement(content);
        return isNotNullElement;
    }
    

}