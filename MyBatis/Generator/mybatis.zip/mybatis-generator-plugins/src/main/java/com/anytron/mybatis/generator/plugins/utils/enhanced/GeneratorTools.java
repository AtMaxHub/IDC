package com.anytron.mybatis.generator.plugins.utils.enhanced;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.PrimitiveTypeWrapper;
import org.mybatis.generator.config.GeneratedKey;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhaojinpeng on 2017/6/21.
 */
public class GeneratorTools {

    /**
     * 获取数据库自增字段
     *
     * @param introspectedTable
     * @return
     */
    public static IntrospectedColumn getKeyColumn(IntrospectedTable introspectedTable) {

        List<IntrospectedColumn> keyColumns = introspectedTable.getPrimaryKeyColumns();
        IntrospectedColumn keyColumn = null;
        //对于usegeneratedkeys来说，只能有一个主键列；
        if (keyColumns.size() == 1) {
            //得到这个唯一的主键列
            keyColumn = keyColumns.get(0);
            //得到这个列映射成Java模型之后的属性对应的Java类型；
            FullyQualifiedJavaType javaType = keyColumn.getFullyQualifiedJavaType();
            //usegeneratedkeys要求主键只能是递增的，所以我们把这个主键属性的类型分别和Integer，Long，Short做对比；
            if (javaType.equals(PrimitiveTypeWrapper.getIntegerInstance())
                    || javaType.equals(PrimitiveTypeWrapper.getLongInstance())
                    || javaType.equals(PrimitiveTypeWrapper.getShortInstance())) {
                return keyColumn;
            }
        }
        return null;

    }

    public static List<IntrospectedColumn> removeGenerateKeyColumns(IntrospectedTable introspectedTable) {
        List<IntrospectedColumn> filteredList = new ArrayList<IntrospectedColumn>();
        GeneratedKey generatedKey = introspectedTable.getGeneratedKey();
        List<IntrospectedColumn> columns = introspectedTable.getAllColumns();
        for (IntrospectedColumn ic : columns) {
            if (!ic.getActualColumnName().equals(generatedKey.getColumn())) {
                filteredList.add(ic);
            }
        }
        return filteredList;
    }
}
