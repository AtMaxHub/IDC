package com.anytron.mybatis.generator.plugins;

import java.util.List;
import java.util.Set;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.JavaVisibility;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.Parameter;
import org.mybatis.generator.api.dom.java.TopLevelClass;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.api.dom.xml.XmlElement;

import com.anytron.mybatis.generator.plugins.utils.BasePlugin;
import com.anytron.mybatis.generator.plugins.utils.JavaElementGeneratorTools;
import com.anytron.mybatis.generator.plugins.utils.XmlElementGeneratorTools;

/**
 * 批量更新生成插件
 *
 * @author Pin Liu
 */
public class BatchUpdatePlugin extends BasePlugin {

    public static final String BATCH_UPDATE = "batchUpdate";

    public static final String PROPERTY_PREFIX = "item.";
    
    @Override
    public boolean validate(List<String> warnings) {
        return true;
    }

	@Override
    public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        FullyQualifiedJavaType listType = FullyQualifiedJavaType.getNewListInstance();
        Set<FullyQualifiedJavaType> importedTypes = interfaze.getImportedTypes();
        if (!importedTypes.contains(listType)){
            interfaze.addImportedType(listType);
        }
        listType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        Method batchInsert = JavaElementGeneratorTools.generateMethod(
        		BATCH_UPDATE,
                JavaVisibility.DEFAULT,
                FullyQualifiedJavaType.getIntInstance(),
                new Parameter(listType, "list")
        );
        commentGenerator.addGeneralMethodComment(batchInsert, introspectedTable);
        // interface 增加方法
        interfaze.addMethod(batchInsert);
        return true;
    }


    @Override
    public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable) {

        XmlElement update = new XmlElement("update");
        update.addAttribute(new Attribute("id", BATCH_UPDATE));

        String parameterType = "java.util.List";

        update.addAttribute(new Attribute("parameterType", parameterType));

        XmlElement foreach = new XmlElement("foreach");
        foreach.addAttribute(new Attribute("collection", "list"));
        foreach.addAttribute(new Attribute("item", "item"));
        foreach.addAttribute(new Attribute("index", "index"));
        foreach.addAttribute(new Attribute("separator", ";"));

        XmlElementGeneratorTools.generateTextBlockAppendTableName(" update ", introspectedTable, foreach);

        XmlElement dynamicElement = new XmlElement("set"); //$NON-NLS-1$
        XmlElementGeneratorTools.generateParameterForSet(PROPERTY_PREFIX, true, introspectedTable.getNonPrimaryKeyColumns(), dynamicElement);

        foreach.addElement(dynamicElement);
        XmlElementGeneratorTools.generateWhereConditions(PROPERTY_PREFIX, introspectedTable.getPrimaryKeyColumns(), foreach);

        update.addElement(foreach);

        document.getRootElement().addElement(update);

        return true;
    }


}