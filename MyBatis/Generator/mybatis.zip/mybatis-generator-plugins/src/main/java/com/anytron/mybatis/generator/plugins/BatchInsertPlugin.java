package com.anytron.mybatis.generator.plugins;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.mybatis3.ListUtilities;
import org.mybatis.generator.config.GeneratedKey;

import com.anytron.mybatis.generator.plugins.utils.BasePlugin;
import com.anytron.mybatis.generator.plugins.utils.JavaElementGeneratorTools;
import com.anytron.mybatis.generator.plugins.utils.XmlElementGeneratorTools;

import java.util.List;
import java.util.Set;

/**
 * 批量插入生成插件
 */
public class BatchInsertPlugin extends BasePlugin {

    public static final String BATCH_INSERT = "batchInsert";
    public static final String PROPERTY_PREFIX = "item.";

    @Override
    public boolean validate(List<String> warnings) {
        return true;
    }

    @Override
    public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        FullyQualifiedJavaType listType = FullyQualifiedJavaType.getNewListInstance();
        Set<FullyQualifiedJavaType> importedTypes = interfaze.getImportedTypes();
        if (!importedTypes.contains(listType)){
            interfaze.addImportedType(listType);
        }
        listType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        Method batchInsert = JavaElementGeneratorTools.generateMethod(
                BATCH_INSERT,
                JavaVisibility.DEFAULT,
                FullyQualifiedJavaType.getIntInstance(),
                new Parameter(listType, "list")
        );
        commentGenerator.addGeneralMethodComment(batchInsert, introspectedTable);
        // interface 增加方法
        interfaze.addMethod(batchInsert);
        logger.debug("itfsw(批量插入插件):" + interfaze.getType().getShortName() + "增加batchInsert方法。");
        return true;
    }

    @Override
    public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable) {
        // 1. batchInsert
        XmlElement batchInsertEle = new XmlElement("insert");
        batchInsertEle.addAttribute(new Attribute("id", BATCH_INSERT));
        // 参数类型
        batchInsertEle.addAttribute(new Attribute("parameterType", "java.util.List"));
        // 添加注释(!!!必须添加注释，overwrite覆盖生成时，@see XmlFileMergerJaxp.isGeneratedNode会去判断注释中是否存在OLD_ELEMENT_TAGS中的一点，例子：@mbg.generated)
        commentGenerator.addComment(batchInsertEle);

        GeneratedKey gk = introspectedTable.getGeneratedKey();

        if (gk != null) {
            XmlElementGeneratorTools.useGeneratedKeysByConfig(batchInsertEle, introspectedTable);
        } else {
            XmlElementGeneratorTools.useGeneratedKeysByData(batchInsertEle, introspectedTable);
        }

        batchInsertEle.addElement(new TextElement("insert into " + introspectedTable.getFullyQualifiedTableNameAtRuntime()));
        batchInsertEle.addElement(XmlElementGeneratorTools.generateKeys(ListUtilities.removeIdentityAndGeneratedAlwaysColumns(introspectedTable.getAllColumns())));

        // 添加foreach节点
        XmlElement foreachElement = new XmlElement("foreach");
        foreachElement.addAttribute(new Attribute("collection", "list"));
        foreachElement.addAttribute(new Attribute("item", "item"));
        foreachElement.addAttribute(new Attribute("separator", ","));

        foreachElement.addElement(XmlElementGeneratorTools.generateValues(ListUtilities.removeIdentityAndGeneratedAlwaysColumns(introspectedTable.getAllColumns()), "item."));


        // values 构建
        batchInsertEle.addElement(new TextElement("values"));
        batchInsertEle.addElement(foreachElement);
        if (context.getPlugins().sqlMapInsertElementGenerated(batchInsertEle, introspectedTable)) {
            document.getRootElement().addElement(batchInsertEle);
            logger.debug("itfsw(批量插入插件):" + introspectedTable.getMyBatis3XmlMapperFileName() + "增加batchInsert实现方法。");
        }

        return true;
    }


}