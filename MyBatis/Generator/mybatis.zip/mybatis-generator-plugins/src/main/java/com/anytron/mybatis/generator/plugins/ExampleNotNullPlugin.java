package com.anytron.mybatis.generator.plugins;

import java.util.List;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.InnerClass;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.Parameter;
import org.mybatis.generator.api.dom.java.PrimitiveTypeWrapper;
import org.mybatis.generator.api.dom.java.TopLevelClass;

import com.anytron.mybatis.generator.plugins.utils.BasePlugin;

/**
 * ---------------------------------------------------------------------------
 * Example 增强插件
 * ---------------------------------------------------------------------------
 *
 * @author: hewei
 * @time:2017/1/16 16:28
 * ---------------------------------------------------------------------------
 */
public class ExampleNotNullPlugin extends BasePlugin {

    @Override
    public boolean validate(List<String> warnings) {
        return true;
    }

    @Override
    public boolean modelExampleClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        try {
            List<InnerClass> innerClasses = topLevelClass.getInnerClasses();
            for (InnerClass innerClass : innerClasses) {
                if ("GeneratedCriteria".equals(innerClass.getType().getShortName())) {
                    List<Method> methods = innerClass.getMethods();
                    for (Method method : methods) {
                        String methodName = method.getName();
                        FullyQualifiedJavaType returnType = method.getReturnType();
                        method.getBodyLines();
                        List<Parameter> parameters = method.getParameters();
                        if (methodName.startsWith("and") && returnType != null && returnType.getShortName().equals("Criteria")) {
                            if (parameters.size() == 1) {
                                Parameter parameter = parameters.get(0);
                                if (parameter.getType().equals(PrimitiveTypeWrapper.getStringInstance())) {
                                    method.addBodyLine(0, "if (value != null && value != \"\") {");
                                    method.addBodyLine(2, "}");
                                } else if (parameter.getType().getShortName().startsWith("List")) {
                                    method.addBodyLine(0, "if (values != null && values.size() != 0) {");
                                    method.addBodyLine(2, "}");
                                } else {
                                    method.addBodyLine(0, "if (value != null) {");
                                    method.addBodyLine(2, "}");
                                }
                            } else if (parameters.size() == 2) {
                                Parameter parameter = parameters.get(0);
                                if (parameter.getType().equals(PrimitiveTypeWrapper.getStringInstance())) {
                                    method.addBodyLine(0, "if (value1 != null && value2 != null && value1 != \"\" && value2 != \"\") {");
                                    method.addBodyLine(2, "}");
                                }else {
                                    method.addBodyLine(0, "if (value1 != null && value2 != null) {");
                                    method.addBodyLine(2, "}");
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }
}
