package com.anytron.mybatis.generator.plugins;

import java.util.List;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.PrimitiveTypeWrapper;
import org.mybatis.generator.config.GeneratedKey;

/**
 * Mysql 获取自增主键
 * Created by zhaojinpeng on 2017/6/21.
 */
public class GeneratorKeyPlugin extends PluginAdapter {

    @Override
    public boolean validate(List<String> list) {
        return true;
    }

    @Override
    public void initialized(IntrospectedTable introspectedTable) {
        GeneratedKey gk = introspectedTable.getGeneratedKey();
        //如果需要生成参数
        if (gk == null) {
            List<IntrospectedColumn> keyColumns = introspectedTable.getPrimaryKeyColumns();
            IntrospectedColumn keyColumn = null;
            //只能有一个主键列；
            if (keyColumns.size() == 1) {
                //得到这个唯一的主键列
                keyColumn = keyColumns.get(0);
                //得到这个列映射成Java模型之后的属性对应的Java类型；
                FullyQualifiedJavaType javaType = keyColumn.getFullyQualifiedJavaType();
                //要求主键只能是递增的，所以我们把这个主键属性的类型分别和Integer，Long，Short做对比；
                if (javaType.equals(PrimitiveTypeWrapper.getIntegerInstance())
                        || javaType.equals(PrimitiveTypeWrapper.getLongInstance())
                        || javaType.equals(PrimitiveTypeWrapper.getShortInstance())) {
                    //设置自增 insert 和 insertSelective 去除字段赋值
                    keyColumn.setIdentity(true);
                    //设置 Mysql generatedKey 用于生成 selectKey
                    GeneratedKey generatedKey = new GeneratedKey(keyColumn.getActualColumnName(), "Mysql", true, "post");
                    introspectedTable.getTableConfiguration().setGeneratedKey(generatedKey);
                }
            }
        }
        super.initialized(introspectedTable);
    }

}
