package com.wbhl.governor.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class TbCardTypeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TbCardTypeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("id =", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("id <>", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("id >", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("id >=", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            if (value != null) {
                addCriterion("id <", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("id <=", value, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("id in", values, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("id not in", values, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("id between", value1, value2, "id");
            }
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("id not between", value1, value2, "id");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceIsNull() {
            addCriterion("card_price is null");
            return (Criteria) this;
        }

        public Criteria andCardPriceIsNotNull() {
            addCriterion("card_price is not null");
            return (Criteria) this;
        }

        public Criteria andCardPriceEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price =", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceNotEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price <>", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceGreaterThan(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price >", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceGreaterThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price >=", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceLessThan(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price <", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceLessThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_price <=", value, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_price in", values, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceNotIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_price not in", values, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_price between", value1, value2, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_price not between", value1, value2, "cardPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeIsNull() {
            addCriterion("card_time is null");
            return (Criteria) this;
        }

        public Criteria andCardTimeIsNotNull() {
            addCriterion("card_time is not null");
            return (Criteria) this;
        }

        public Criteria andCardTimeEqualTo(Long value) {
            if (value != null) {
                addCriterion("card_time =", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("card_time <>", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeGreaterThan(Long value) {
            if (value != null) {
                addCriterion("card_time >", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("card_time >=", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeLessThan(Long value) {
            if (value != null) {
                addCriterion("card_time <", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("card_time <=", value, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_time in", values, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_time not in", values, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_time between", value1, value2, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardTimeNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_time not between", value1, value2, "cardTime");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceIsNull() {
            addCriterion("card_original_price is null");
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceIsNotNull() {
            addCriterion("card_original_price is not null");
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price =", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceNotEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price <>", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceGreaterThan(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price >", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceGreaterThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price >=", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceLessThan(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price <", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceLessThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("card_original_price <=", value, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_original_price in", values, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceNotIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_original_price not in", values, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_original_price between", value1, value2, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardOriginalPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("card_original_price not between", value1, value2, "cardOriginalPrice");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescIsNull() {
            addCriterion("card_desc is null");
            return (Criteria) this;
        }

        public Criteria andCardDescIsNotNull() {
            addCriterion("card_desc is not null");
            return (Criteria) this;
        }

        public Criteria andCardDescEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc =", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescNotEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc <>", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescGreaterThan(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc >", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescGreaterThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc >=", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescLessThan(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc <", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescLessThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc <=", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescLike(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc like", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescNotLike(String value) {
            if (value != null && value != "") {
                addCriterion("card_desc not like", value, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_desc in", values, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescNotIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("card_desc not in", values, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("card_desc between", value1, value2, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andCardDescNotBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("card_desc not between", value1, value2, "cardDesc");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("remark =", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("remark <>", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            if (value != null && value != "") {
                addCriterion("remark >", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("remark >=", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            if (value != null && value != "") {
                addCriterion("remark <", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("remark <=", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            if (value != null && value != "") {
                addCriterion("remark like", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            if (value != null && value != "") {
                addCriterion("remark not like", value, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("remark in", values, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("remark not in", values, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("remark between", value1, value2, "remark");
            }
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("remark not between", value1, value2, "remark");
            }
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}