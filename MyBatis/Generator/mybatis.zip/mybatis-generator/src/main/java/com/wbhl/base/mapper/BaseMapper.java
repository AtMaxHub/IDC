package com.wbhl.base.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface BaseMapper<T,E> {
	
	/**
	 * 方法名: deleteByPrimaryKey
	 * <br/>作用: 通过主键进行删除
	 * <br/>作者: YanPengJie
	 * <br/>日期: 2018年5月24日下午8:36:29
	 * <br/>@throws 
	 * <br/>@param id
	 * <br/>@return int
	 */
	int deleteByPrimaryKey(Object id);

	/**
	 * 方法名: insert
	 * <br/>作用: 插入数据,不区分是否字段数据为空
	 * <br/>作者: YanPengJie
	 * <br/>日期: 2018年5月24日下午8:36:49
	 * <br/>@throws 
	 * <br/>@param record
	 * <br/>@return int
	 */
    int insert(T record);

    /**
     * 方法名: insertSelective
     * <br/>作用: 插入非空字段数据
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:37:16
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return int
     */
    int insertSelective(T record);

    /**
     * 方法名: selectByPrimaryKey
     * <br/>作用: 通过主键查询
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:37:55
     * <br/>@throws 
     * <br/>@param id
     * <br/>@return T
     */
    T selectByPrimaryKey(Object id);

    /**
     * 方法名: updateByPrimaryKeySelective
     * <br/>作用: 通过主键更新非空字段数据
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:38:12
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return int
     */
    int updateByPrimaryKeySelective(T record);

    /**
     * 方法名: updateByPrimaryKey
     * <br/>作用: 通过主键更新数据,不区分是否字段数据为空
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:38:33
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return int
     */
    int updateByPrimaryKey(T record);

    /**
     * 方法名: batchInsert
     * <br/>作用: 批量插入
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:39:04
     * <br/>@throws 
     * <br/>@param list
     * <br/>@return int
     */
    int batchInsert(List<T> list);

    /**
     * 方法名: batchUpdate
     * <br/>作用: 批量更新
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:39:14
     * <br/>@throws 
     * <br/>@param list
     * <br/>@return int
     */
    int batchUpdate(List<T> list);

    /**
     * 方法名: upsert
     * <br/>作用: 更新或者插入数据,数据存在就更新不存在就插入,不区分是否字段数据为空
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:39:25
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return int
     */
    int upsert(T record);

    /**
     * 方法名: upsertSelective
     * <br/>作用: 更新或者插入数据,数据存在就更新不存在就插入,仅对非空字段有效
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月24日下午8:40:13
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return int
     */
    int upsertSelective(T record);
    
    /**
     * 方法名: selectAll
     * <br/>作用: 查询全部数据
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月25日下午3:15:05
     * <br/>@throws 
     * <br/>@return List<T>
     */
    List<T> selectAll();

    /**
     * 方法名: selectOne
     * <br/>作用: 根据model查询字段值不为空的数据仅能查出来一个请确保需求使用
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月25日下午3:15:17
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return T
     */
    T selectOne(T record);

    /**
     * 方法名: select
     * <br/>作用: 根据model查询字段值不为空的数据
     * <br/>作者: YanPengJie
     * <br/>日期: 2018年5月25日下午3:16:20
     * <br/>@throws 
     * <br/>@param record
     * <br/>@return List<T>
     */
    List<T> select(T record);
    
    long countByExample(E example);

    int deleteByExample(E example);

    List<T> selectByExampleWithRowbounds(E example, RowBounds rowBounds);

    List<T> selectByExample(E example);

    int updateByExampleSelective(@Param("record") T record, @Param("example") E example);

    int updateByExample(@Param("record") T record, @Param("example") E example);



}
