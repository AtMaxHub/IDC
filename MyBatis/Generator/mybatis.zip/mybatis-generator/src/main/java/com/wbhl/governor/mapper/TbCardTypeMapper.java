package com.wbhl.governor.mapper;

import com.wbhl.base.mapper.BaseMapper;
import com.wbhl.governor.entity.TbCardType;
import com.wbhl.governor.entity.TbCardTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface TbCardTypeMapper extends BaseMapper<TbCardType, TbCardTypeExample> {
}