package com.wbhl.governor.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class TbCardType implements Serializable {
    /**
     * 购卡类型主键(续费类型主键)id
     */
    private Long id;

    /**
     * 购卡价格(现价)
     */
    private BigDecimal cardPrice;

    /**
     * 可购时长
     */
    private Long cardTime;

    /**
     * 原价
     */
    private BigDecimal cardOriginalPrice;

    /**
     * 会员卡说明
     */
    private String cardDesc;

    /**
     * 备注
     */
    private String remark;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getCardPrice() {
        return cardPrice;
    }

    public void setCardPrice(BigDecimal cardPrice) {
        this.cardPrice = cardPrice;
    }

    public Long getCardTime() {
        return cardTime;
    }

    public void setCardTime(Long cardTime) {
        this.cardTime = cardTime;
    }

    public BigDecimal getCardOriginalPrice() {
        return cardOriginalPrice;
    }

    public void setCardOriginalPrice(BigDecimal cardOriginalPrice) {
        this.cardOriginalPrice = cardOriginalPrice;
    }

    public String getCardDesc() {
        return cardDesc;
    }

    public void setCardDesc(String cardDesc) {
        this.cardDesc = cardDesc == null ? null : cardDesc.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", cardPrice=").append(cardPrice);
        sb.append(", cardTime=").append(cardTime);
        sb.append(", cardOriginalPrice=").append(cardOriginalPrice);
        sb.append(", cardDesc=").append(cardDesc);
        sb.append(", remark=").append(remark);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public enum Column {
        id("id"),
        cardPrice("card_price"),
        cardTime("card_time"),
        cardOriginalPrice("card_original_price"),
        cardDesc("card_desc"),
        remark("remark");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}